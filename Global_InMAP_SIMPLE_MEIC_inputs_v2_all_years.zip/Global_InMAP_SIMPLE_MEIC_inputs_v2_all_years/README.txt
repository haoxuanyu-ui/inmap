Global InMAP simple MEIC input package (v2, all source years)

Purpose
- Minimal physical-emission input tables for Global InMAP testing and source-receptor runs.
- This package contains MEIC emissions only; it does not contain MRIO responsibility data.
- MRIO should be connected only after Global InMAP returns source-receptor concentration outputs.

Years included
- 2012, 2015, 2017, 2018, 2020.

Fields
- PM2_5: primary PM2.5 emissions, mapped from MEIC PM25.
- SOx: SO2 emissions, mapped from MEIC SO2.
- NOx: NOx emissions.
- NH3: NH3 emissions.
- VOC: VOC emissions.
- Unit: kg/year.

How to use
1. For a first baseline test, use baseline_by_year/MEIC_2020_baseline_all5_kgyr.csv.
2. Join the CSV to a China province boundary polygon file using Join_Key or Province.
3. Export the joined polygon file to shapefile/geopackage for Global InMAP.
4. Once baseline works, use source_runs_by_year/<year>/ to run 31 province-source scenarios for that year.

Important
- These CSV files contain no geometry.
- The source-run files are all5 physical emission perturbations: one province has non-zero PM2_5, SOx, NOx, NH3, and VOC, all other provinces are zero.
- Residential emissions are included because Global InMAP needs physical emissions. This is separate from the later MRIO responsibility allocation step.
